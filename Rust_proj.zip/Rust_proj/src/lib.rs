fn main() {
    println!("Hello from your Rust CLI project!");
}
